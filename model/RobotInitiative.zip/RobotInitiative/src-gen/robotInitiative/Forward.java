/**
 */
package robotInitiative;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Forward</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see robotInitiative.RobotInitiativePackage#getForward()
 * @model
 * @generated
 */
public interface Forward extends Movement {
} // Forward
