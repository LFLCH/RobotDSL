/**
 */
package robotInitiative.impl;

import org.eclipse.emf.ecore.EClass;

import robotInitiative.Left;
import robotInitiative.RobotInitiativePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Left</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LeftImpl extends MovementImpl implements Left {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LeftImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RobotInitiativePackage.Literals.LEFT;
	}

} //LeftImpl
