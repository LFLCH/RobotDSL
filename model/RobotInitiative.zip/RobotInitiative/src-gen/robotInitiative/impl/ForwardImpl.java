/**
 */
package robotInitiative.impl;

import org.eclipse.emf.ecore.EClass;

import robotInitiative.Forward;
import robotInitiative.RobotInitiativePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Forward</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ForwardImpl extends MovementImpl implements Forward {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ForwardImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RobotInitiativePackage.Literals.FORWARD;
	}

} //ForwardImpl
