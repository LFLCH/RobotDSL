/**
 */
package robotInitiative.impl;

import org.eclipse.emf.ecore.EClass;

import robotInitiative.Right;
import robotInitiative.RobotInitiativePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Right</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RightImpl extends MovementImpl implements Right {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RightImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RobotInitiativePackage.Literals.RIGHT;
	}

} //RightImpl
