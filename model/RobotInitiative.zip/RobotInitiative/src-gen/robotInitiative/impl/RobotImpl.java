/**
 */
package robotInitiative.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import robotInitiative.Movement;
import robotInitiative.Robot;
import robotInitiative.RobotInitiativePackage;
import robotInitiative.Rotation;
import robotInitiative.Speed;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Robot</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link robotInitiative.impl.RobotImpl#getMovements <em>Movements</em>}</li>
 *   <li>{@link robotInitiative.impl.RobotImpl#getSpeed <em>Speed</em>}</li>
 *   <li>{@link robotInitiative.impl.RobotImpl#getRotation <em>Rotation</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RobotImpl extends MinimalEObjectImpl.Container implements Robot {
	/**
	 * The cached value of the '{@link #getMovements() <em>Movements</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMovements()
	 * @generated
	 * @ordered
	 */
	protected EList<Movement> movements;

	/**
	 * The cached value of the '{@link #getSpeed() <em>Speed</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpeed()
	 * @generated
	 * @ordered
	 */
	protected Speed speed;

	/**
	 * The cached value of the '{@link #getRotation() <em>Rotation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRotation()
	 * @generated
	 * @ordered
	 */
	protected Rotation rotation;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RobotImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RobotInitiativePackage.Literals.ROBOT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Movement> getMovements() {
		if (movements == null) {
			movements = new EObjectContainmentEList<Movement>(Movement.class, this,
					RobotInitiativePackage.ROBOT__MOVEMENTS);
		}
		return movements;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Speed getSpeed() {
		if (speed != null && speed.eIsProxy()) {
			InternalEObject oldSpeed = (InternalEObject) speed;
			speed = (Speed) eResolveProxy(oldSpeed);
			if (speed != oldSpeed) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, RobotInitiativePackage.ROBOT__SPEED,
							oldSpeed, speed));
			}
		}
		return speed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Speed basicGetSpeed() {
		return speed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSpeed(Speed newSpeed) {
		Speed oldSpeed = speed;
		speed = newSpeed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RobotInitiativePackage.ROBOT__SPEED, oldSpeed,
					speed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Rotation getRotation() {
		if (rotation != null && rotation.eIsProxy()) {
			InternalEObject oldRotation = (InternalEObject) rotation;
			rotation = (Rotation) eResolveProxy(oldRotation);
			if (rotation != oldRotation) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, RobotInitiativePackage.ROBOT__ROTATION,
							oldRotation, rotation));
			}
		}
		return rotation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Rotation basicGetRotation() {
		return rotation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRotation(Rotation newRotation) {
		Rotation oldRotation = rotation;
		rotation = newRotation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RobotInitiativePackage.ROBOT__ROTATION, oldRotation,
					rotation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSpeed() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case RobotInitiativePackage.ROBOT__MOVEMENTS:
			return ((InternalEList<?>) getMovements()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RobotInitiativePackage.ROBOT__MOVEMENTS:
			return getMovements();
		case RobotInitiativePackage.ROBOT__SPEED:
			if (resolve)
				return getSpeed();
			return basicGetSpeed();
		case RobotInitiativePackage.ROBOT__ROTATION:
			if (resolve)
				return getRotation();
			return basicGetRotation();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RobotInitiativePackage.ROBOT__MOVEMENTS:
			getMovements().clear();
			getMovements().addAll((Collection<? extends Movement>) newValue);
			return;
		case RobotInitiativePackage.ROBOT__SPEED:
			setSpeed((Speed) newValue);
			return;
		case RobotInitiativePackage.ROBOT__ROTATION:
			setRotation((Rotation) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RobotInitiativePackage.ROBOT__MOVEMENTS:
			getMovements().clear();
			return;
		case RobotInitiativePackage.ROBOT__SPEED:
			setSpeed((Speed) null);
			return;
		case RobotInitiativePackage.ROBOT__ROTATION:
			setRotation((Rotation) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RobotInitiativePackage.ROBOT__MOVEMENTS:
			return movements != null && !movements.isEmpty();
		case RobotInitiativePackage.ROBOT__SPEED:
			return speed != null;
		case RobotInitiativePackage.ROBOT__ROTATION:
			return rotation != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RobotInitiativePackage.ROBOT___SET_SPEED:
			setSpeed();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

} //RobotImpl
