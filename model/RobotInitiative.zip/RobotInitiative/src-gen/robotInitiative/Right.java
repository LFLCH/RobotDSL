/**
 */
package robotInitiative;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Right</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see robotInitiative.RobotInitiativePackage#getRight()
 * @model
 * @generated
 */
public interface Right extends Movement {
} // Right
