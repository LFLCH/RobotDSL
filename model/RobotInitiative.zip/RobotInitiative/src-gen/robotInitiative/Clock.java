/**
 */
package robotInitiative;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Clock</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see robotInitiative.RobotInitiativePackage#getClock()
 * @model
 * @generated
 */
public interface Clock extends Rotation {
} // Clock
