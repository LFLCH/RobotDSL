/**
 */
package robotInitiative;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Distance</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see robotInitiative.RobotInitiativePackage#getDistance()
 * @model
 * @generated
 */
public interface Distance extends EObject {
} // Distance
