/**
 */
package robotInitiative;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Movement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link robotInitiative.Movement#getDistance <em>Distance</em>}</li>
 *   <li>{@link robotInitiative.Movement#getValue <em>Value</em>}</li>
 * </ul>
 *
 * @see robotInitiative.RobotInitiativePackage#getMovement()
 * @model abstract="true"
 * @generated
 */
public interface Movement extends EObject {
	/**
	 * Returns the value of the '<em><b>Distance</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Distance</em>' reference.
	 * @see #setDistance(Distance)
	 * @see robotInitiative.RobotInitiativePackage#getMovement_Distance()
	 * @model required="true"
	 * @generated
	 */
	Distance getDistance();

	/**
	 * Sets the value of the '{@link robotInitiative.Movement#getDistance <em>Distance</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Distance</em>' reference.
	 * @see #getDistance()
	 * @generated
	 */
	void setDistance(Distance value);

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(int)
	 * @see robotInitiative.RobotInitiativePackage#getMovement_Value()
	 * @model
	 * @generated
	 */
	int getValue();

	/**
	 * Sets the value of the '{@link robotInitiative.Movement#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(int value);

} // Movement
