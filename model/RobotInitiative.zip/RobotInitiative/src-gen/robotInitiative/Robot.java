/**
 */
package robotInitiative;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Robot</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link robotInitiative.Robot#getMovements <em>Movements</em>}</li>
 *   <li>{@link robotInitiative.Robot#getSpeed <em>Speed</em>}</li>
 *   <li>{@link robotInitiative.Robot#getRotation <em>Rotation</em>}</li>
 * </ul>
 *
 * @see robotInitiative.RobotInitiativePackage#getRobot()
 * @model
 * @generated
 */
public interface Robot extends EObject {
	/**
	 * Returns the value of the '<em><b>Movements</b></em>' containment reference list.
	 * The list contents are of type {@link robotInitiative.Movement}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Movements</em>' containment reference list.
	 * @see robotInitiative.RobotInitiativePackage#getRobot_Movements()
	 * @model containment="true"
	 * @generated
	 */
	EList<Movement> getMovements();

	/**
	 * Returns the value of the '<em><b>Speed</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Speed</em>' reference.
	 * @see #setSpeed(Speed)
	 * @see robotInitiative.RobotInitiativePackage#getRobot_Speed()
	 * @model
	 * @generated
	 */
	Speed getSpeed();

	/**
	 * Sets the value of the '{@link robotInitiative.Robot#getSpeed <em>Speed</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Speed</em>' reference.
	 * @see #getSpeed()
	 * @generated
	 */
	void setSpeed(Speed value);

	/**
	 * Returns the value of the '<em><b>Rotation</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rotation</em>' reference.
	 * @see #setRotation(Rotation)
	 * @see robotInitiative.RobotInitiativePackage#getRobot_Rotation()
	 * @model
	 * @generated
	 */
	Rotation getRotation();

	/**
	 * Sets the value of the '{@link robotInitiative.Robot#getRotation <em>Rotation</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rotation</em>' reference.
	 * @see #getRotation()
	 * @generated
	 */
	void setRotation(Rotation value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void setSpeed();

} // Robot
