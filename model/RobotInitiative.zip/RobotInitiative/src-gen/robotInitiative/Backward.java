/**
 */
package robotInitiative;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Backward</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see robotInitiative.RobotInitiativePackage#getBackward()
 * @model
 * @generated
 */
public interface Backward extends Movement {
} // Backward
