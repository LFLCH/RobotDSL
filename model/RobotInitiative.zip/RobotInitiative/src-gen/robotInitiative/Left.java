/**
 */
package robotInitiative;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Left</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see robotInitiative.RobotInitiativePackage#getLeft()
 * @model
 * @generated
 */
public interface Left extends Movement {
} // Left
